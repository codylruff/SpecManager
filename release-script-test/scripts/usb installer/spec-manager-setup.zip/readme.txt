

- To install simply click the 'setupsm' file.

- The application should automatically load upon installation.

- To open the application afterward click on the spec-manager shortcut
  saved to your desktop.
